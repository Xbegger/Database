function [FDS,USPOLY,FDPARM]=ut_contourfft(varargin)
%ut_contourfft	shape description and contour analysis in the Fourier domain
%
%   [FDS,USPOLY] = UT_CONTOURFFT(BND) calculates the Fourier descriptors of
%   the closed boundaries of objects (regions, segments) found in BND. The
%   format of BND must agree with the format of boundaries produced by
%   BWBOUNDARIES or BWTRACEBOUNDARY. 
%       UT_CONTOURFFT first resamples each boundary in order to obtain a
%   uniform resampling along the running arc length of the boundary so that
%   fft-processing becomes feasible. Uniform resampling is done by assuming
%   that the coordinates in the boundary list are the vertices of a
%   polygon. The new boundary points are found by uniform sampling along
%   the arc length of this polygon. 
%       The resampled boundary is first represented in the complex plane
%   where the column-coordinate is the real part, and the row-coordinate
%   the imaginary part. Thus, in this presentation, a boundary forms a
%   contour in the complex plane (i.e. a closed curve that is uniformly
%   sampled along the running arc length). Application of FFT to this
%   boundary provides the Fourier descriptors that are returned in FDS. The
%   uniform resampled boundaries are returned in USPOLY.
%
%   If BND is a cell array pointing to a number of boundaries, then FDS and
%   USPOLY are also cell arrays (pointing to the Fourier descriptors and
%   resampled boundaries, respectively). IF BND is just a Q-by-2 array of
%   boundary points, then FDS and USPOLY are NFFT-by-1 and NFFT-by-2
%   arrays, respectively. (NFFT is the number of points of the resampled
%   boundaries).
%       
%   [FDS,USPOLY] = UT_CONOURFFT(BND,...,OPTION,OPTIONVAL,...) calculates
%   the Fourier descriptors with some parameter(s) set to OPTIONVAL. 
%   The  following options can be used to change parameters: 
%   'nfft':     sets the number of points, NFFT, of the resampled boundaries.
%               OPTIONVAL must be an integer number greater than 1 (though
%               any useful number is about 16 or more). Default: 64.
%   'fdlist':   sets the list of Fourier descriptors that is actually
%               outputted. For instance, to output the -2nd and the 4th
%               Fourier descriptor, OPTIONVAL must be [-2 4]. In order to
%               have a range of Fourier descriptors, for instance,
%               -4,-3,-2,-1,0,2, define OPTIONVAL as [-4:2].
%
%   [FDS,USPOLY,FDPARM] = UT_CONOURFFT(BND,...,OPTION...) calculates the
%   Fourier descriptors with some options on. The following options are
%   available:
%   'nmag':     This option provides a simple way to obtain a shape
%               description that is invariant to the position, orientation,
%               size, and starting point of the contours. The invariance is
%               obtained by:
%               - nullifying the 0-th Fourier descriptor (position
%                 invariance).
%               - dividing all Fourier descriptors by the magnitude of the
%                 1-st Fourier descriptor (size invariance).
%               - only considering the magnitude of the Fourier descriptors
%                 (orientation and starting point invariance).
%               Note that by applying this normalization, the 0-th and 1-th
%               Fourier descriptors do not provide any information.
%                   A disadvantage of this normalization method is that it
%               is not reversible. That is, it is not possible to
%               reconstruct the shape given this set of normalized Fourier
%               descriptors.
%   'normfd':   This option provides a more sophisticated method to obtain
%               invariant descriptors. The method is explained in (Ref 1).
%               This method is advantageous because these normalized
%               Fourier descriptors are reversible with respect to shape.
%               The normalized contour is obtained by application of IFFT
%               (the inverse fft) to the complete set of Fourier
%               descriptors. For instance, if BND is a single contour,
%               then:
%                       [FDS,USPOLY,FDPARM] = UT_CONOURFFT(BND,'normfd');
%                       normBND = ifft(FDS);
%                       plot(normBND);
%               depicts the normalized contour.
%                   In addition, this option also provides measurements
%               from each contour. These measurements are returned in
%               FDPARM (either a cell array of vectors, or a single
%               vector). The following measurements are returned in each
%               vector fdparm: 
%               fdparm(1):  column-coordinate of the center of gravity of
%                           the contour.
%               fdparm(2):  row-coordinate of the center of gravity of the
%                           contour.
%               fdparm(3):  the size of the contour expressed as the radius
%                           of the best fitting circle.
%               fdparm(4):  orientation of the contour expressed as an
%                           angle with respect to the orientation of the
%                           normalized contour.
%               fdparm(5):  starting point expressed as a distance measured
%                           along the running arc length and with reference
%                           to the starting point of the normalized
%                           contour.
%               fdparm(6):  the area enclosed by the contour.
%               fdparm(7):  the perimeter of the contour.
%
%   Copyright: F. van der Heijden, F.vanderHeijden@utwente.nl
%   Laboratory for Measurements and Instrumentation
%   University of Twente, the Netherlands
%   Version 1.0, date: 27-10-2004
%
% Reference: F. van der Heijden: Image based Measurement Systems - Object
% Recognition and Parameter Estimation, J.Wiley&sons, Chichester, pp
% 261-266, 1994. 
%
%   See also BWBOUNDARIES, BWTRACEBOUNDARY, FFT, IFFT


[BND,operator,FDSLIST,nfft]=ParseInputs(varargin{:});

  
FDPARM=[];

if iscell(BND)
    for i=1:length(BND)
        bnd = BND{i};
        [fds,uspoly,fdparm] = contourfft(bnd,operator,FDSLIST,nfft);
        FDS{i} = fds;
        USPOLY{i} = uspoly;
        FDPARM{i} = fdparm;
    end
else
    [FDS,USPOLY,FDPARM] = contourfft(BND,operator,FDSLIST,nfft);
end


%----------------------------------------------------------------------
% processing of individual boundaries
%----------------------------------------------------------------------
function [fds,bndc,fdparm] = contourfft(bnd,operator,FDSLIST,nfft)

fdparm=[];

if size(bnd,2)~=2 | size(bnd,1)==1
    error('invalid boundary');
end
if sum(bnd(1,:) ~= bnd(end,:))
    error('boundary must be closed');
end
bndus = usplgn(bnd,nfft);   % uniform resamplng
bndc = bndus(:,2) + 1i*bndus(:,1);
fds = fft(bndc);

if strcmp(operator,'nmag')
    fds = abs(fds);
    fds = fds/fds(2);
end

if strcmp(operator,'normfd')
    % area and perimeter
    k = 0:nfft-1;
    k(ceil(nfft/2)+1:end) = k(ceil(nfft/2)+1:end)-nfft;
    fdparm(6) = pi*sum(abs(fds').^2.*k)/nfft^2;           % area
    fdparm(7) = 2*pi*sum(abs(fds').^2.*k.^2)^0.5/nfft;    % perimeter
    
    % position:
    fdparm(1) = real(fds(1))/nfft;
    fdparm(2) = imag(fds(1))/nfft;
    fds(1)=0;
    % size:
    fdparm(3) = abs(fds(2))/nfft;
    fds = fds/fdparm(3);
    % rotation and starting point:
    [fmax,L] = max(abs(fds(3:end)));    % find largest fd (suppress Z0 and Z1)
    L = L+2;                            % correction for suppressed Z0 and Z1
    theta1 = angle(fds(2));
    theta2 = angle(fds(L));
    if L>ceil(nfft/2)+1, M=L-nfft-1; else M=L-1; end
                                        % correction for Matlab array indexing
    beta = (theta1-theta2)/(M-1);
    alfa = (theta2-theta1*M)/(M-1);
    Z = fds.*exp(1i*(alfa+k'*beta));     % rotate and shift
    for m=1:abs(M-1)
        A(m) = sum(real(Z).*abs(Z));    % ambiguity resolving function
        Z = Z.*exp(1i*2*pi*(k'-1)/(M-1));
    end    
    [amax,m] = max(A);
    fds = Z.*exp((m-1)*1i*2*pi*(k'-1)/(M-1));
    fdparm(5) = (theta1-theta2+2*pi*(m-1))/(M-1);   % start point shift
    fdparm(5) = fdparm(5)*fdparm(7)/(2*pi);
    fdparm(4) = -theta1 - beta;                     % rotation
end

if ~isempty(FDSLIST)
    fds = fds(FDSLIST);
end



%----------------------------------------------------------------------
% polygonal uniform resampling
%----------------------------------------------------------------------
function bndout = usplgn(bndin,nbnd)
% bndin: A 2-dim array storing the boundary points of a closed contour. The
%        coordinates are stored in the rows.
% nbnd:  The target number of boundary points.

% compute length of segments, perimeter and stepsize
inc=diff(bndin);
ds = (inc(:,1).^2+inc(:,2).^2).^0.5;
perimeter = sum(ds);
stepsize = perimeter/nbnd;             

% start uniform sampling
bndout = zeros(nbnd,2);
bndout(1,:) = bndin(1,:);
n=2;                  % index of next output bnd point
si = ds(1);           % traced arc length of input bnd
i = 1;                % index of last processed input bnd point 
so = 0;               % traced arc length of output bnd

for n=2:nbnd
    so = so + stepsize;                 % traced arc length of n-th output bnd pnt
    while si<so
        i  = i+1;
        si = si+ds(i);
    end
    fraction = (so-si+ds(i))/ds(i);
    bndout(n,:) = bndin(i,:) + fraction *(bndin(i+1,:)-bndin(i,:));
end


%----------------------------------------------------------------------
% Subfunction ParseInputs
%----------------------------------------------------------------------

function [BND,operator,FDSLIST,nfft] =  ParseInputs(varargin);
error(nargchk(1,30,nargin));


BND = varargin{1};

%defaults
operator = 'fft';
nfft = 64;
FDSLIST = [];

options = {'fft','normfd','nmag','nfft','fdlist'};
operators = {'fft','normfd','nmag'};

if nargin>1
    for k=2:length(varargin)
        if ischar(varargin{k})
            string = lower(varargin{k});
            j = strmatch(string,options,'exact');
            if isempty(j)
                error(['Invalid input string: ''' varargin{k} '''.']);
            end
            j = strmatch(string,operators,'exact');
            if ~isempty(j)
                operator = operators(j);
                continue;
            end
            if strcmp(string,'nfft');
                if ~(nargin>k & isnumeric(varargin{k+1}))
                    error('Invalid OPTIONVAL after ''nfft''');
                end
                k=k+1;
                nfft = varargin{k};
            end
            if strcmp(string,'fdlist');
                if ~(nargin>k & isnumeric(varargin{k+1}))
                    error('Invalid OPTIONVAL after ''fdlist''');
                end
                k=k+1;
                FDSLIST = varargin{k};
                siz=size(FDSLIST);
                if ((siz(1)>1) & (siz(2)==1))
                    FDSLIST=FDSLIST';
                elseif ((siz(1)>1) & (siz(2)>1))
                    error('FDSLIST must be a vector');
                end
            end
        end
    end
end
if ~isempty(FDSLIST)
    FDSLIST = mod(FDSLIST,nfft)+1;
end

