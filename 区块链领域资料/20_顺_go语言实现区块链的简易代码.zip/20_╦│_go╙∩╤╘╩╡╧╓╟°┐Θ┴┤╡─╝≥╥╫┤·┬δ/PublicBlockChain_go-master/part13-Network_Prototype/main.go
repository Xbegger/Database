package main

import (

	"chaors.com/LearnGo/publicChaorsChain/part13-Network_Prototype/BLC"
)

func main() {

	cli := BLC.CLI{}
	cli.Run()
}