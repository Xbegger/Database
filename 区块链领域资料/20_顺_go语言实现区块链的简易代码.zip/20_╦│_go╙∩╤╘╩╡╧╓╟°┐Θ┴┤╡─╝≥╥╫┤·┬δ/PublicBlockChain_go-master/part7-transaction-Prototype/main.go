package main

import (

	"chaors.com/LearnGo/publicChaorsChain/part7-transaction-Prototype/BLC"
	//"fmt"
	//"os"
	//"flag"
	//"log"
)

func main() {

	cli := BLC.CLI{}
	cli.Run()
}
