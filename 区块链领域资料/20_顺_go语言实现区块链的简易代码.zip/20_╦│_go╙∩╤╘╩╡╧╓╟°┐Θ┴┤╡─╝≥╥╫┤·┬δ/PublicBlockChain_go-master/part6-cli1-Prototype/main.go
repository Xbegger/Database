package main

import (

	"chaors.com/LearnGo/publicChaorsChain/part6-cli1-Prototype/BLC"
	//"fmt"
	//"os"
	//"flag"
	//"log"
)

func main() {

	cli := BLC.CLI{}
	cli.Run()
}
